<?php namespace Emotions\Events;

abstract class Event {

	//

}
