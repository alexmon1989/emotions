<?php namespace Emotions;

use Illuminate\Database\Eloquent\Model;

class Slider extends Model {

	//

}
