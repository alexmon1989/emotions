<?php namespace Emotions;

use Illuminate\Database\Eloquent\Model;

class Order extends Model {

}
