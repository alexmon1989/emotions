<?php namespace Emotions\Commands;

abstract class Command {

	//

}
